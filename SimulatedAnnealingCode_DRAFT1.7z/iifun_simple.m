function [iaac,ias]=iifun_simple(dat,type,riv,iaac_old,ias_old)

if type==1

    rcount=size(dat,2);
    iaac=NaN(rcount,1);
    iaac_test=NaN(rcount,1);
    ias=NaN(rcount,1);
    
    for r=1:rcount
        
        dat_a=sum(reshape(dat(:,r),12,[]))';

        autocorr_vec=autocorr(dat_a,1);
        iaac(r)=autocorr_vec(2);
        ias(r)=std(dat_a);
    end
    
elseif type==2
    
    iaac=iaac_old;
    ias=ias_old;
    
    dat_a=sum(reshape(dat(:,riv),12,[]))';
    
    autocorr_vec=autocorr(dat_a,1);
    iaac(riv)=autocorr_vec(2);
    ias(riv)=std(dat_a);
    
    
end
