function out=ccorrfun(dat)
rcount=size(dat,2);
out=NaN(rcount);
for i=1:rcount
    for j=1:rcount
        d1=dat(:,i);d12=d1;
        d2=dat(:,j);d22=d2;
        d12(isnan(d1.*d2))=[];
        d22(isnan(d1.*d2))=[];
        d1=d12;
        d2=d22;
        
%         These two are equivalent
%         Xcorr_Val=crosscorr(d1,d2,1);
%         c1=Xcorr_Val(2);

        Xcorr_Val=corrcoef(d1,d2);
        c1=Xcorr_Val(1,2);
        
%         c1=mean(d1.*d2);
        out(j,i)=c1;
    end
end
