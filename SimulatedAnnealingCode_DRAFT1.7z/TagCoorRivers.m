function out=TagCoorRivers(Alldat,dat)

%% Develop Correlation of Shortened Rivers to All Rivers
% Flag vector
lvec_dat=zeros(size(Alldat,2),1);

% Find locations of 'edit' in 'dat'

% 1. Find zero vectors, flag -1
for j=1:size(Alldat,2)
    ndat_vec=Alldat(:,j);
    if mean(ndat_vec)==0 && std(ndat_vec)==0
        lvec_dat(j)=-1;
    end
end

% 2. Find repeated lag synthetic vectors, flag -2
for j=1:size(Alldat,2)
    if lvec_dat(j)==0
        ndat_vec=Alldat(:,j);
        if sum(ndat_vec(1:12)-ndat_vec(13:24))==0
            lvec_dat(j)=-2;
        end
    end
end

% 3. Find matching vectors, flag with edit loc
for i=1:size(dat,2)
    for j=1:size(Alldat,2)
        if lvec_dat(j)==0
            ndat_vec=Alldat(:,j);
            nedit_vec=dat(:,i);
            if round((mean(ndat_vec)*1000))==round((mean(nedit_vec)*1000))
                lvec_dat(j)=i;
            end
        end
    end
end

% 4. Find correlated vectors, flag with edit loc*100
nset=zeros(size(dat,2),size(Alldat,2));
for i=1:size(dat,2);
    for j=1:size(Alldat,2);
        ndat_vec=Alldat(:,j);
        nedit_vec=dat(:,i);
        if lvec_dat(j)==0;
            cset=corr([ndat_vec nedit_vec]);
            if isnan(cset(1,2));
                nset(i,j)=1;
            end
            if cset(1,2) > 0.98;
                lvec_dat(j)=i*100;
            end
            
           
 %           if round(cset(1,2)*10000)==10000
 %               lvec_dat(j)=i*100;
 %           end
        end
    end
end

% Index flag vector
lvec_dat=[(1:162)' lvec_dat];
out=lvec_dat;


end



