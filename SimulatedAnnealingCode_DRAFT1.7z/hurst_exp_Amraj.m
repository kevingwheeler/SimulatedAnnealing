function out=hurst_exp(dat,type,riv,h_old)
    if type==1
            r_size=size(dat,2);
            out=NaN(1,r_size);
            for r=1:r_size  
                z_annual = sum(reshape(dat(:,r),12,[]))';
                out(r)=Hurst(z_annual');
            end
    elseif type==2
        out=h_old;
        z_annual = sum(reshape(dat(:,riv),12,[]))';
        out(:,riv) = Hurst(z_annual');
    end    
end


