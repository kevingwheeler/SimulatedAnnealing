function [mout,sout]=msfun(dat,type,riv,m_old,s_old)
if type==1
    rcount=size(dat,2);
    mout=NaN(12,rcount);
    sout=NaN(12,rcount);
    for r=1:rcount
        for m=1:12
            dat_r=dat(m:12:end,r);
            dat_r(isnan(dat_r))=[];
            mout(m,r)=mean(dat_r);
            sout(m,r)=std(dat_r);
        end
    end
elseif type==2
    mout=m_old;
    sout=s_old;
    for m=1:12
        dat_r=dat(m:12:end,riv);
        dat_r(isnan(dat_r))=[];
        mout(m,riv)=mean(dat_r);
        sout(m,riv)=std(dat_r);
    end
end
