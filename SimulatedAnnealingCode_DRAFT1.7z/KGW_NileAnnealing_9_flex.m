% % % Numerical Rivers 2 % % %

% A simulated annealing multi-site time series generator
% Can be run to match time series from training data or apply change 

% Operational statistics are:
% Cross correlations of monthly time series(CC)
% Autocorrelations of monthly time series (AC)
% Means of monthly time series (M)
% Standard Deviations of monthly time series (S)
% Interannual Autocorrelations (IAAC)
% Interannual Standard Deviations (IAS)
% Hurst Exponent (H)


%% TIMING

% Start a count
tic

DistrubutedToggle = 0;
OutputFolderID = 1;

% delete(gcp('nocreate'))
% parpool('local');

%% INITIALISE DISTRIBUTED SETUP
if DistrubutedToggle == 1
    Location = getenv('SLURM_SUBMIT_DIR');		
    TaskID = str2num(getenv('SLURM_ARRAY_TASK_ID'));
end


%% LOAD DATA
Alldat=load('nile_dat.csv');
dat=csvread('nile_edit.csv');

lvec_dat= TagCoorRivers(Alldat,dat);

% RUN PARAMETERS
% Number of repeated runs
runcount=1;
% Length of generated time series in years
ndat_length_y=50;

% SIMULATED ANNEALING REGIME
% Starting Temperature
tstart=0.2;
% Temperature Reduction Threshold
pthresh=(numel(dat)*2);
% Total Number of Iterations
itercount=1000;
ReportIncrement=10;
% Temperature Change Parameter
tparam=1.2;

iaac_coeff=0;
ias_coeff=0;

%Climate Change Parameters
ias_multiplier = 1.0;
iaac_multiplier = 1.0;
hurst_multiplier = 1.0;

% FURTHER CALCULATIONS
% Number of rivers to be modelled
rcount=size(dat,2);
% Length of generated series in months
ndat_length_m=ndat_length_y*12;

% Create a 3D array of historical data (months,years,river)
datMonthBlock=NaN(12,size(dat,1)/12,rcount);
for r=1:rcount
   datMonthBlock(:,:,r)=reshape(dat(:,r),12,[]);
end


%% OBSERVATION STATISTICS

% Series cross correlation
cc_obs=ccorrfun(dat);

% Monthly cross correlations
cc_month_obs = NaN(rcount,rcount,12);

for i = 1:12
    cc_month_obs (:,:,i) = ccorrfun(permute(datMonthBlock(i,:,:),[2,3,1]));
end
cc_month_obs(isnan(cc_month_obs)) = 0;

% Autocorrelation
ac_obs=acorrfun_simple(dat,1,0,0);
% Mean, Standard Deviation
[m_obs,s_obs]=msfun(dat,1,0,0,0);

% [Minimum Observed Maximum] IAAC and IAS
[iaac_obs,ias_obs]=iifun_simple(dat,1,0,0,0);

% Hurst Exponent
h_obs=hurst_exp_Amraj(dat,1,0,0);
% Alldat_Sum = sum(Alldat,2);
% hBasin_obs = hurst_exp_Amraj(Alldat_Sum,1,0,0);

% Modify targets for Climate Change
ias_obs = ias_obs*ias_multiplier;
iaac_obs = iaac_obs*iaac_multiplier;
h_obs = h_obs*hurst_multiplier;
% hBasin_obs = hBasin_obs*hurst_multiplier;

% Bound iaac from -1.0 to 1.0
iaac_obs = max(iaac_obs,-1.0);
iaac_obs = min(iaac_obs,1.0);

h_obs = max(h_obs,0.5);
h_obs = min(h_obs,1.0);
% hBasin_obs = max(hBasin_obs,0.5);
% hBasin_obs = min(hBasin_obs,1.0);


%% RUN LOOP

% For each generated time series set ('run')


for runset=1:runcount
    
    ReportStep = ReportIncrement  
    
    if DistrubutedToggle == 1
        % For Array on Cluster
        % Assign Unique array/run counter
        % Seed psuedorandom generator
        FileNum = (TaskID-1)*runcount+runset;
        rng(FileNum);
    else
        FileNum = runset
    end

    WriteLocation = strcat('LocalOutputFolder', num2str(OutputFolderID))
    OutputFileName = strcat(WriteLocation, '/', 'Trace', num2str(FileNum), '.csv');
    Output_OF_FileName = strcat(WriteLocation, '/', 'Trace_of_', num2str(FileNum), '.csv');
    Output_OF_DE_FileName = strcat(WriteLocation, '/', 'Trace_ofde_', num2str(FileNum), '.csv');
    OutputTraceParameters = strcat(WriteLocation, '/', 'TraceParameters', num2str(FileNum), '.csv');
    
    Final_OutputFileName = strcat(WriteLocation, '/', 'Final_Trace', num2str(FileNum), '.csv');
    Final_Output_OF_FileName = strcat(WriteLocation, '/', 'Final_Trace_of_', num2str(FileNum), '.csv');
    Final_Output_OF_DE_FileName = strcat(WriteLocation, '/', 'Final_Trace_ofde_', num2str(FileNum), '.csv');
    Final_OutputTraceParameters = strcat(WriteLocation, '/', 'Final_TraceParameters', num2str(FileNum), '.csv');


    % Initialise
    % set temperature
    T=tstart;
    % set a counter to temperature change
    pcount=0;
    
    % Set up output
    ndat=NaN(ndat_length_m,rcount);
    Initial_ndatMonthBlock=NaN(12,ndat_length_y,rcount);

    % Populates each month from random sampling of historical months 
    for r=1:rcount
        for monthcount=1:12
           MonthFlowList=datMonthBlock(monthcount,:,r);
           Initial_ndatMonthBlock(monthcount,:,r)=MonthFlowList(randi(size(MonthFlowList,2),1,ndat_length_y));
        end
    end
    
    % Reshapes the 3D month-year-river block format to 2D
    % timeseries-river format
    for r=1:rcount
        InitialRivSheet=Initial_ndatMonthBlock(:,:,r);
        ndat(:,r)=reshape(InitialRivSheet,1,[]);
    end
    
    % Get Initial Statistics for New Data
    
    % Series cross correlation
    cc_new=ccorrfun(ndat);
    
    % Monthly cross correlations
    cc_month_new = NaN(rcount,rcount,12);
    for i = 1:12
        cc_month_new (:,:,i) = ccorrfun(permute(Initial_ndatMonthBlock(i,:,:),[2,3,1]));
    end
    cc_month_new(isnan(cc_month_new)) = 0;
    
    ac_new=acorrfun_simple(ndat,1,0,0);
    [m_new,s_new]=msfun(ndat,1,0,0,0);
    [iaac_new,ias_new]=iifun_simple(ndat,1,0,0,0);
    h_new=hurst_exp_Amraj(ndat,1,0,0);
%     hBasin_new=CalcGlobalHurst(ndat,dat,Alldat,lvec_dat);
     
    % Set a vector to receive OF values
    ofrecord=NaN(itercount,1);
    ofrecord_detail=NaN(itercount,10);
%     TraceParameters=NaN(itercount,10);
    
    % Find Ranges for Each OF Component
    % We need:
    %	- VECTORS (vec) - sum of error for each river
    %   - REPEATING VECTOR (vec_rep) - vecs repeated a set number of times
    %   - VALUES - a single figure for each vec/OF
    
    cc_range_vec=sum(abs(cc_obs-cc_new));
    ac_range_vec=sum(abs(ac_obs-ac_new));
    m_range_vec=sum(abs(m_obs-m_new));
    s_range_vec=sum(abs(s_obs-s_new));
    iaac_range_vec=abs(iaac_obs-iaac_new)';
    ias_range_vec=abs(ias_obs-ias_new)';
    h_range_vec=abs(h_obs-h_new);
    
    cc_range_val=sum(cc_range_vec);
    ac_range_val=sum(ac_range_vec);
    m_range_val=sum(m_range_vec);
    s_range_val=sum(s_range_vec);
    iaac_range_val=sum(iaac_range_vec);
    ias_range_val=sum(ias_range_vec);
    h_range_val=sum(h_range_vec);
%     hBasin_range_val=abs(hBasin_obs-hBasin_new);
    
    cc_month_range_val=sum(sum(sum(abs(cc_month_obs-cc_month_new),3),1));
    
    % Set a target for Objective Functions
    of_target=inf; 
    
    
    %% MODEL LOOP
    % For each iteration
    for iter=1:itercount
        
        %Select Random River to Modify
        ir=randi(rcount);  
        
        %Select random months to Swap
        im1=randi(ndat_length_m);
        im2=randi(ndat_length_m);
        
        % Find the value for this month and river
        v1=ndat(im1,ir);
        v2=ndat(im2,ir);
        
        % Swap
        nalt=ndat;
        nalt(im2,ir)=v1;
        nalt(im1,ir)=v2;
        
        % Create a 3D array of historical data (months,years,river)
        naltMonthBlock=NaN(12,size(nalt,1)/12,rcount);
        for r=1:rcount
           naltMonthBlock(:,:,r)=reshape(nalt(:,r),12,[]);
        end
        
        % Find statistics for the new series
        cc_alt=ccorrfun(nalt);
        ac_alt=acorrfun_simple(nalt,2,ir,ac_new);
        [m_alt,s_alt]=msfun(nalt,2,ir,m_new,s_new);
        [iaac_alt,ias_alt]=iifun_simple(nalt,2,ir,iaac_new,ias_new);
        h_alt=hurst_exp_Amraj(nalt,2,ir,h_new);
%         hBasin_alt=CalcGlobalHurst(nalt,dat,Alldat,lvec_dat);
        
        cc_month_alt = NaN(rcount,rcount,12);

        for i = 1:12
            cc_month_alt (:,:,i) = ccorrfun(permute(naltMonthBlock(i,:,:),[2,3,1]));
        end
        cc_month_alt(isnan(cc_month_alt)) = 0;
        
        
        % Find the normalised error
        
%         Using the Simple Cross correlations
        cc_of=sum(sum(abs(cc_obs-cc_alt)))/cc_range_val;
        ac_of=sum(sum(abs(ac_obs-ac_alt)))/ac_range_val;
        m_of=sum(sum(abs(m_obs-m_alt)))/m_range_val;
        s_of=sum(sum(abs(s_obs-s_alt)))/s_range_val;
        iaac_of=sum(abs(iaac_obs-iaac_alt))/iaac_range_val;
        ias_of=sum(abs(ias_obs-ias_alt))/ias_range_val;
        h_of=sum(abs(h_obs-h_alt))/h_range_val;
%         hBasin_of=sum(abs(hBasin_obs-hBasin_alt))/hBasin_range_val;
        cc_month_of=sum(sum(sum(abs(cc_month_obs-cc_month_alt),3),1))/cc_month_range_val;
        
        % Evaluate the complete objective function
        of=(cc_of^2)+(ac_of^2)+(m_of^2)+(s_of^2)+(iaac_of^2)+(ias_of^2)+(h_of^2)+(cc_month_of^2);
%         of=(cc_of^2)+(ac_of^2)+(m_of^2)+(s_of^2)+(iaac_of^2)+(ias_of^2)+(hBasin_of^2)+(cc_month_of^2);
        

             
        % Record OF progress
        ofrecord(iter,:) = of_target;
    
        % Compare current and previous objective functions
        % Account for temperature
        if of<of_target || rand()<exp(-(of-of_target)/T)
            % Update all the objective function components
            SuccessSwaps=1;
            ndat=nalt;
            cc_new=cc_alt;
            ac_new=ac_alt;
            m_new=m_alt;
            s_new=s_alt;
            iaac_new=iaac_alt;
            ias_new=ias_alt;
            h_new=h_alt;
%             hBasin_new=hBasin_alt;
            cc_month_new=cc_month_alt;
            of_target=of;
        else
            SuccessSwaps=0;
        end
        
        % If we have reached the temperature update point
        if pcount>=pthresh
            pcount=0;
            T=T/tparam;
        else
            pcount=pcount+1;
        end
       
        of_detail=[SuccessSwaps ir cc_of ac_of m_of s_of iaac_of ias_of h_of cc_month_of];
%         of_detail=[SuccessSwaps ir cc_of ac_of m_of s_of iaac_of ias_of hBasin_of cc_month_of];        
        ofrecord_detail(iter,:) = of_detail;
        
            %% Write on Report Step        
        if iter == ReportStep
            TraceParameters=[iter T of_target cc_range_val ac_range_val m_range_val s_range_val iaac_range_val ias_range_val h_range_val cc_month_range_val];
            if FileNum==1
                csvwrite(OutputFileName,ndat);
                csvwrite(OutputTraceParameters,TraceParameters);
                csvwrite(Output_OF_FileName,ofrecord);
                csvwrite(Output_OF_DE_FileName,ofrecord_detail);
            else
                csvwrite(OutputFileName,ndat);
                csvwrite(OutputTraceParameters,TraceParameters);
            end
            ReportStep = ReportStep + ReportIncrement;
        end
    end     
    
      %% Write After Completion
    TraceParameters=[iter T of_target cc_range_val ac_range_val m_range_val s_range_val iaac_range_val ias_range_val h_range_val cc_month_range_val];
    if FileNum==1
        csvwrite(Final_OutputFileName,ndat);
        csvwrite(Final_OutputTraceParameters,TraceParameters);
        csvwrite(Final_Output_OF_FileName,ofrecord);
        csvwrite(Final_Output_OF_DE_FileName,ofrecord_detail);
    else
        csvwrite(Final_OutputFileName,ndat);
        csvwrite(Final_OutputTraceParameters,TraceParameters);
    end
end

% parpool close;

%% TIMING
% End count
toc
